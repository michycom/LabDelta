# LabDelta

**Medicine already has the data. LabDelta helps clinicians see it.**

Privacy-first, local, open-source desktop software for medical professionals. LabDelta compares longitudinal laboratory reports, highlights changes, groups affected values into overlapping functional laboratory profiles, and preserves source traceability.

It does not diagnose disease, estimate disease probability, recommend treatment, or recommend additional tests.

Status: frozen product specification; implementation pending.
